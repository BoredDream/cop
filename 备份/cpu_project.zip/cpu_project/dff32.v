// dff32.v : 32位D触发器，用作程序计数器PC
// 时钟上升沿把下址npc打入；clrn低电平异步复位，PC清零（程序从地址0开始）
module dff32 (d, clk, clrn, q);
    input  [31:0] d;
    input         clk, clrn;
    output reg [31:0] q;
    always @(posedge clk or negedge clrn) begin
        if (!clrn) q <= 32'h0;
        else       q <= d;
    end
endmodule
