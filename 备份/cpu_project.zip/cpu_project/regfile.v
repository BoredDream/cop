// regfile.v : 寄存器堆，32个32位寄存器
// 两个读端口（rna→qa, rnb→qb，组合读出），一个写端口（wn,d，时钟沿写入）
// $0 恒为0：读0号恒返回0，写0号被忽略
module regfile (rna, rnb, d, wn, we, clk, clrn, qa, qb);
    input  [4:0]  rna, rnb;   // 读端口a、b的寄存器号
    input  [31:0] d;          // 写入数据
    input  [4:0]  wn;         // 写端口寄存器号
    input         we;         // 写使能
    input         clk, clrn;  // 时钟、清零（低有效）
    output [31:0] qa, qb;     // 两个读出数据

    reg [31:0] register [1:31];   // $1~$31，$0不占存储

    assign qa = (rna == 5'b0) ? 32'h0 : register[rna];
    assign qb = (rnb == 5'b0) ? 32'h0 : register[rnb];

    integer i;
    always @(posedge clk or negedge clrn) begin
        if (!clrn) begin
            for (i = 1; i < 32; i = i + 1)
                register[i] <= 32'h0;
        end else if (we && (wn != 5'b0)) begin
            register[wn] <= d;
        end
    end
endmodule
