// shift.v : 32位移位器
// right=0          : 逻辑左移  (sll)
// right=1, arith=0 : 逻辑右移  (srl)
// right=1, arith=1 : 算术右移  (sra, 符号位填充)
module shift (d, sa, right, arith, sh);
    input  [31:0] d;       // 被移位数据
    input  [4:0]  sa;      // 移位位数 0~31
    input         right, arith;
    output reg [31:0] sh;
    always @* begin
        if (!right)
            sh = d << sa;                  // 逻辑左移
        else if (!arith)
            sh = d >> sa;                  // 逻辑右移，高位补0
        else
            sh = $signed(d) >>> sa;        // 算术右移，高位补符号位
    end
endmodule
