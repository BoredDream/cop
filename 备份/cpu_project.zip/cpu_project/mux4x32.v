// mux4x32.v : 32位四选一多路选择器，选出最终的ALU结果
module mux4x32 (a0, a1, a2, a3, s, y);
    input  [31:0] a0, a1, a2, a3;
    input  [1:0]  s;
    output reg [31:0] y;
    always @* begin
        case (s)
            2'b00: y = a0;   // 加/减结果
            2'b01: y = a1;   // 与/或结果
            2'b10: y = a2;   // 异或/lui结果
            2'b11: y = a3;   // 移位结果
        endcase
    end
endmodule
