// sccomp_tb.v : 单周期计算机仿真测试（仅仿真用，不加入综合）
// 跑完整测试程序后自动核对寄存器和存储器的最终值
`timescale 1ns/1ns
module sccomp_tb;
    reg clock, resetn;
    wire [31:0] inst, pc, aluout, memout;

    sccomp dut (clock, resetn, inst, pc, aluout, memout);

    initial begin
        clock = 0; resetn = 0;
        #5  resetn = 1;
    end
    always #10 clock = ~clock;     // 周期20ns

    // 打印前30个周期的执行轨迹（报告里可截图对照）
    integer cyc;
    initial begin
        cyc = 0;
        $display("  pc       inst     aluout   memout");
        forever begin
            @(posedge clock); #1;
            if (cyc < 30)
                $display("%h %h %h %h", pc, inst, aluout, memout);
            cyc = cyc + 1;
        end
    end

    task check32 (input [255:0] name, input [31:0] got, input [31:0] exp);
        if (got === exp) $display("PASS  %0s = %h", name, got);
        else             $display("FAIL  %0s = %h (期望 %h)", name, got, exp);
    endtask

    initial begin
        #4000;   // 200个周期，程序早已到达finish死循环
        $display("---- 最终状态校验 ----");
        check32("$2  (sum结果)",   dut.cpu.rf.register[2],  32'h00000258);
        check32("$31 (返回地址)",  dut.cpu.rf.register[31], 32'h00000010);
        check32("$6  (or结果)",    dut.cpu.rf.register[6],  32'hFFFFFFFF);
        check32("$7  (and结果)",   dut.cpu.rf.register[7],  32'h0000FFFF);
        check32("$10 (andi结果)",  dut.cpu.rf.register[10], 32'h0000FFFF);
        check32("$8  (sra终值)",   dut.cpu.rf.register[8],  32'h00000001);
        check32("$5  (addi终值)",  dut.cpu.rf.register[5],  32'hFFFFFFFF);
        check32("mem[60] (sw写入)",dut.dmem.ram[6'h18],     32'h00000258);
        if (pc == 32'h0000005C) $display("PASS  PC停在finish(0x5C)死循环");
        else                    $display("FAIL  PC = %h (期望 0x5C)", pc);
        $stop;
    end
endmodule
