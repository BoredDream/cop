// sccomp.v : 单周期计算机 = CPU + 指令存储器 + 数据存储器
module sccomp (clock, resetn, inst, pc, aluout, memout);
    input         clock, resetn;
    output [31:0] inst, pc, aluout, memout;

    wire [31:0] data;
    wire        wmem;

    sccpu     cpu  (clock, resetn, inst, memout, pc, wmem, aluout, data);
    scinstmem imem (pc, inst);
    scdatamem dmem (clock, memout, data, aluout, wmem);
endmodule
