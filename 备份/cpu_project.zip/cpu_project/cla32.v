// cla32.v : 32位CLA的顶层封装，屏蔽内部g/p信号，对外只给出和s
module cla32 (a, b, c_in, s);
    input  [31:0] a, b;
    input         c_in;
    output [31:0] s;
    wire          g_out, p_out;   // 内部信号，不再向外传递
    cla_32 cla (a, b, c_in, g_out, p_out, s);
endmodule
