// add.v : 1位加法单元（超前进位的最底层）
// 不产生进位输出，只产生 进位生成g 和 进位传播p，由上层g_p计算进位
module add (a, b, c, g, p, s);
    input  a, b, c;     // 两个加数位 与 来自低位的进位
    output g, p, s;     // g=进位生成, p=进位传播, s=本位和
    assign s = a ^ b ^ c;
    assign g = a & b;   // 两位都为1时必产生进位
    assign p = a | b;   // 任一位为1时可传播低位进位
endmodule
