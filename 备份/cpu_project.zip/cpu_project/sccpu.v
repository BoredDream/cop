// sccpu.v : 单周期CPU数据通路（不含存储器）
// 每个时钟周期完成一条指令的 取指→译码→执行→访存→写回 全过程
// ------------------------------------------------------------------
// 端口：
//   inst  来自指令存储器的指令       mem  来自数据存储器的读出数据
//   pc    送指令存储器的取指地址     alu  ALU结果（兼作访存地址）
//   data  送数据存储器的写入数据(qb) wmem 数据存储器写使能
// ------------------------------------------------------------------
module sccpu (clock, resetn, inst, mem, pc, wmem, alu, data);
    input         clock, resetn;
    input  [31:0] inst, mem;
    output [31:0] pc, alu, data;
    output        wmem;

    // ---------- 指令字段切分 ----------
    wire [5:0]  op   = inst[31:26];
    wire [4:0]  rs   = inst[25:21];
    wire [4:0]  rt   = inst[20:16];
    wire [4:0]  rd   = inst[15:11];
    wire [4:0]  sa   = inst[10:6];
    wire [5:0]  func = inst[5:0];
    wire [15:0] imm  = inst[15:0];
    wire [25:0] addr = inst[25:0];

    // ---------- 控制部件 ----------
    wire        wreg, regrt, jal, m2reg, shift, aluimm, sext, zero;
    wire [3:0]  aluc;
    wire [1:0]  pcsource;
    sccu cu (op, func, zero, wmem, wreg, regrt, m2reg, aluc, shift,
             aluimm, pcsource, jal, sext);

    // ---------- 取指与下址 ----------
    wire [31:0] npc, p4, bpc, jpc;
    dff32 ip (npc, clock, resetn, pc);            // PC寄存器
    cla32 pcplus4 (pc, 32'h4, 1'b0, p4);          // PC+4

    wire        e = sext & imm[15];               // 符号扩展位
    wire [15:0] sa16 = {16{e}};
    wire [31:0] immediate = {sa16, imm};          // 扩展后的立即数
    wire [31:0] offset = {sa16[13:0], imm, 2'b00};// 分支偏移×4
    cla32 br_adr (p4, offset, 1'b0, bpc);         // 分支目标=PC+4+offset<<2
    assign jpc = {p4[31:28], addr, 2'b00};        // j/jal跳转目标

    mux4x32 nextpc (p4, bpc, qa, jpc, pcsource, npc);  // 下址选择器

    // ---------- 寄存器堆 ----------
    wire [31:0] qa, qb, wdi;
    wire [4:0]  reg_dest, wn;
    mux2x5 reg_wn (rd, rt, regrt, reg_dest);      // 写回号：rd或rt
    assign wn = reg_dest | {5{jal}};              // jal强制写$31
    regfile rf (rs, rt, wdi, wn, wreg, clock, resetn, qa, qb);

    // ---------- 执行（ALU） ----------
    wire [31:0] alua, alub;
    mux2x32 alu_a (qa, {27'h0, sa}, shift, alua); // a口：qa或移位位数
    mux2x32 alu_b (qb, immediate, aluimm, alub);  // b口：qb或立即数
    alu al_unit (alua, alub, aluc, alu, zero);

    // ---------- 访存与写回 ----------
    assign data = qb;                             // sw写入数据
    wire [31:0] alu_mem;
    mux2x32 result (alu, mem, m2reg, alu_mem);    // ALU结果或lw数据
    mux2x32 link (alu_mem, p4, jal, wdi);         // jal写回PC+4
endmodule
