// sccu.v : 单周期CPU控制部件
// 输入op/func完成20条指令译码，输出全部控制信号
// ------------------------------------------------------------------
// 控制信号一览：
//   wreg     1=写寄存器堆
//   regrt    写回寄存器号选择：0=rd（R型），1=rt（I型）
//   jal      1=jal指令：写$31，写入值为PC+4
//   m2reg    写回数据选择：0=ALU结果，1=存储器读出
//   shift    ALU的a口选择：0=qa，1=sa（移位指令）
//   aluimm   ALU的b口选择：0=qb，1=立即数
//   sext     立即数扩展方式：1=符号扩展，0=零扩展
//   wmem     1=写数据存储器（sw）
//   aluc     ALU运算编码（与任务二一致）
//   pcsource 下址选择：00=PC+4，01=分支目标，10=qa(jr)，11=跳转目标(j/jal)
// ------------------------------------------------------------------
module sccu (op, func, z, wmem, wreg, regrt, m2reg, aluc, shift,
             aluimm, pcsource, jal, sext);
    input  [5:0] op, func;
    input        z;             // 来自ALU的零标志
    output       wreg, regrt, jal, m2reg, shift, aluimm, sext, wmem;
    output [3:0] aluc;
    output [1:0] pcsource;

    // ------------ 20条指令译码 ------------
    wire r_type = ~|op;                          // op全0为R型
    wire i_add  = r_type & (func == 6'b100000);
    wire i_sub  = r_type & (func == 6'b100010);
    wire i_and  = r_type & (func == 6'b100100);
    wire i_or   = r_type & (func == 6'b100101);
    wire i_xor  = r_type & (func == 6'b100110);
    wire i_sll  = r_type & (func == 6'b000000);
    wire i_srl  = r_type & (func == 6'b000010);
    wire i_sra  = r_type & (func == 6'b000011);
    wire i_jr   = r_type & (func == 6'b001000);

    wire i_addi = (op == 6'b001000);
    wire i_andi = (op == 6'b001100);
    wire i_ori  = (op == 6'b001101);
    wire i_xori = (op == 6'b001110);
    wire i_lw   = (op == 6'b100011);
    wire i_sw   = (op == 6'b101011);
    wire i_beq  = (op == 6'b000100);
    wire i_bne  = (op == 6'b000101);
    wire i_lui  = (op == 6'b001111);
    wire i_j    = (op == 6'b000010);
    wire i_jal  = (op == 6'b000011);

    // ------------ 控制信号逻辑表达式 ------------
    assign wreg   = i_add | i_sub | i_and | i_or  | i_xor |
                    i_sll | i_srl | i_sra | i_addi| i_andi|
                    i_ori | i_xori| i_lw  | i_lui | i_jal;
    assign regrt  = i_addi | i_andi | i_ori | i_xori | i_lw | i_lui;
    assign jal    = i_jal;
    assign m2reg  = i_lw;
    assign shift  = i_sll | i_srl | i_sra;
    assign aluimm = i_addi | i_andi | i_ori | i_xori | i_lw | i_lui | i_sw;
    assign sext   = i_addi | i_lw | i_sw | i_beq | i_bne;
    assign wmem   = i_sw;

    // ALU编码（与任务二的aluc表一致）
    // ADD=x000 SUB=x100 AND=x001 OR=x101 XOR=x010 LUI=x110
    // SLL=0011 SRL=0111 SRA=1111
    assign aluc[3] = i_sra;
    assign aluc[2] = i_sub | i_or  | i_srl | i_sra | i_ori | i_lui |
                     i_beq | i_bne;
    assign aluc[1] = i_xor | i_sll | i_srl | i_sra | i_xori| i_lui;
    assign aluc[0] = i_and | i_or  | i_sll | i_srl | i_sra |
                     i_andi| i_ori;

    // 下址选择
    assign pcsource[1] = i_jr | i_j | i_jal;
    assign pcsource[0] = (i_beq & z) | (i_bne & ~z) | i_j | i_jal;
endmodule
