// g_p.v : 超前进位逻辑块（CLA的核心）
// 把两个低层块的 g,p 合并成更高一层的 g_out,p_out，
// 并直接算出高半块的输入进位 c_out（不必等低半块逐位算完——"超前"所在）
//   c_out = g[0] | p[0]&c_in      （低半块向高半块的进位）
//   g_out = g[1] | p[1]&g[0]      （整块的进位生成）
//   p_out = p[1] & p[0]           （整块的进位传播）
module g_p (g, p, c_in, g_out, p_out, c_out);
    input  [1:0] g, p;   // 低半块g[0],p[0]；高半块g[1],p[1]
    input        c_in;
    output       g_out, p_out, c_out;
    assign g_out = g[1] | (p[1] & g[0]);
    assign p_out = p[1] & p[0];
    assign c_out = g[0] | (p[0] & c_in);
endmodule
