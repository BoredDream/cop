// scinstmem.v : 指令存储器（ROM，组合读出）
// 按字寻址：取a[7:2]作为指令序号（最多32条指令，128字节空间）
// 内置测试程序覆盖全部20条指令：
//   主程序调用sum子程序（jal/jr），累加数据存储器中4个数；
//   随后用sw/lw/sub验证访存，loop2循环验证逻辑与分支指令，
//   最后验证三种移位，finish处死循环。
module scinstmem (a, inst);
    input  [31:0] a;          // 指令地址（PC）
    output reg [31:0] inst;   // 取出的指令

    always @* begin
        case (a[7:2])
            //                                   地址   汇编
            6'h00: inst = 32'h3c010000; // (00) main:  lui  $1, 0
            6'h01: inst = 32'h34240050; // (04)        ori  $4, $1, 0x50
            6'h02: inst = 32'h20050004; // (08)        addi $5, $0, 4
            6'h03: inst = 32'h0c000018; // (0c) call:  jal  sum
            6'h04: inst = 32'hac820000; // (10)        sw   $2, 0($4)
            6'h05: inst = 32'h8c890000; // (14)        lw   $9, 0($4)
            6'h06: inst = 32'h01244022; // (18)        sub  $8, $9, $4
            6'h07: inst = 32'h20050003; // (1c)        addi $5, $0, 3
            6'h08: inst = 32'h20a5ffff; // (20) loop2: addi $5, $5, -1
            6'h09: inst = 32'h34a8ffff; // (24)        ori  $8, $5, 0xffff
            6'h0A: inst = 32'h39085555; // (28)        xori $8, $8, 0x5555
            6'h0B: inst = 32'h2009ffff; // (2c)        addi $9, $0, -1
            6'h0C: inst = 32'h312affff; // (30)        andi $10, $9, 0xffff
            6'h0D: inst = 32'h01493025; // (34)        or   $6, $10, $9
            6'h0E: inst = 32'h01494026; // (38)        xor  $8, $10, $9
            6'h0F: inst = 32'h01463824; // (3c)        and  $7, $10, $6
            6'h10: inst = 32'h10a00001; // (40)        beq  $5, $0, shift
            6'h11: inst = 32'h08000008; // (44)        j    loop2
            6'h12: inst = 32'h2005ffff; // (48) shift: addi $5, $0, -1
            6'h13: inst = 32'h000543c0; // (4c)        sll  $8, $5, 15
            6'h14: inst = 32'h00084400; // (50)        sll  $8, $8, 16
            6'h15: inst = 32'h000843c2; // (54)        srl  $8, $8, 15
            6'h16: inst = 32'h00084403; // (58)        sra  $8, $8, 16
            6'h17: inst = 32'h08000017; // (5c) finish:j    finish
            6'h18: inst = 32'h00004020; // (60) sum:   add  $8, $0, $0
            6'h19: inst = 32'h8c890000; // (64) loop:  lw   $9, 0($4)
            6'h1A: inst = 32'h01094020; // (68)        add  $8, $8, $9
            6'h1B: inst = 32'h20a5ffff; // (6c)        addi $5, $5, -1
            6'h1C: inst = 32'h20840004; // (70)        addi $4, $4, 4
            6'h1D: inst = 32'h14a0fffb; // (74)        bne  $5, $0, loop
            6'h1E: inst = 32'h00081000; // (78)        sll  $2, $8, 0
            6'h1F: inst = 32'h03e00008; // (7c)        jr   $31
            default: inst = 32'h0;
        endcase
    end
endmodule
