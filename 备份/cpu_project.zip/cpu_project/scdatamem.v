// scdatamem.v : 数据存储器（RAM，64字×32位=256字节）
// 读：组合输出 ram[addr]；写：时钟上升沿且we=1时写入（sw指令）
// 初始数据放在 0x50~0x5C，供sum子程序累加：
//   A3 + 27 + 79 + 115 = 1F8（十六进制）
module scdatamem (clk, dataout, datain, addr, we);
    input         clk, we;
    input  [31:0] datain, addr;
    output [31:0] dataout;

    reg [31:0] ram [0:63];

    assign dataout = ram[addr[7:2]];     // 按字寻址

    always @(posedge clk) begin
        if (we) ram[addr[7:2]] <= datain;
    end

    integer i;
    initial begin
        for (i = 0; i < 64; i = i + 1) ram[i] = 32'h0;
        ram[6'h14] = 32'h000000A3;   // 地址0x50
        ram[6'h15] = 32'h00000027;   // 地址0x54
        ram[6'h16] = 32'h00000079;   // 地址0x58
        ram[6'h17] = 32'h00000115;   // 地址0x5C
    end
endmodule
