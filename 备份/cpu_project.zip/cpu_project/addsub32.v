// addsub32.v : 32位加/减法器（基于超前进位加法器cla32）
// sub=0 : s = a + b
// sub=1 : s = a - b = a + (~b) + 1   （b按位取反，初始进位置1）
module addsub32 (a, b, sub, s);
    input  [31:0] a, b;
    input         sub;
    output [31:0] s;
    // sub=1时 b^{32{1}} = ~b，且c_in=1，正好构成补码减法
    cla32 as32 (a, b ^ {32{sub}}, sub, s);
endmodule
