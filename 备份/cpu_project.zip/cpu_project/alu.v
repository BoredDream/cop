// alu.v : 32位ALU，支持目标指令集中的9种运算
// ------------------------------------------------------------------
//  aluc[3:0] | 操作          | 对应指令
//  x000=0000 | ADD  a+b      | add / addi / lw / sw（算地址）
//  x100=0100 | SUB  a-b      | sub / beq / bne（比较）
//  x001=0001 | AND  a&b      | and / andi
//  x101=0101 | OR   a|b      | or  / ori
//  x010=0010 | XOR  a^b      | xor / xori
//  x110=0110 | LUI  {b[15:0],16'h0}        | lui
//  0011      | SLL  b << a[4:0]            | sll
//  0111      | SRL  b >> a[4:0]            | srl
//  1111      | SRA  b >>> a[4:0] (算术)    | sra
// ------------------------------------------------------------------
//  选择规则：aluc[1:0]选大类(加减/与或/异或lui/移位)
//            aluc[2]  在类内二选一(加|减、与|或、异或|lui、左移|右移)
//            aluc[3]  右移时区分逻辑|算术
module alu (a, b, aluc, r, z);
    input  [31:0] a, b;
    input  [3:0]  aluc;
    output [31:0] r;
    output        z;        // 零标志：r==0 时 z=1（供beq/bne判断）

    // 逻辑运算
    wire [31:0] d_and = a & b;
    wire [31:0] d_or  = a | b;
    wire [31:0] d_xor = a ^ b;
    wire [31:0] d_lui = {b[15:0], 16'h0};

    // 类内二选一
    wire [31:0] d_and_or  = aluc[2] ? d_or  : d_and;
    wire [31:0] d_xor_lui = aluc[2] ? d_lui : d_xor;

    // 算术运算（超前进位加/减法器）与移位
    wire [31:0] d_as, d_sh;
    addsub32 as32    (a, b, aluc[2], d_as);
    shift    shifter (b, a[4:0], aluc[2], aluc[3], d_sh);

    // 最终选择
    mux4x32 select (d_as, d_and_or, d_xor_lui, d_sh, aluc[1:0], r);

    assign z = ~|r;   // 32位结果按位或再取反
endmodule
