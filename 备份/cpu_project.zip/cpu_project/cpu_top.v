// cpu_top.v : 任务三板级顶层（项目顶层实体名设为 cpu_top）
// ==================================================================
// 板上资源（端口名与DE1-SoC手册一致）：
//   KEY[0]   按住=复位（PC清零，程序从头跑）
//   KEY[1]   单步模式下：每按一次执行一条指令
//   SW[8]    时钟模式：0=自动慢时钟(约1.5Hz)，1=手动单步(KEY[1])
//   SW[9]    HEX3~0显示内容：0=ALU结果低16位，1=ALU结果高16位
//   HEX5~4   当前PC的指令序号（PC[9:2]，即第几条指令，对照程序清单）
//   HEX3~0   ALU结果（按SW[9]选高/低16位）
//   LEDR[0]  CPU时钟指示（自动模式下闪烁）
// ==================================================================
module cpu_top (
    input         CLOCK_50,
    input  [3:0]  KEY,
    input  [9:0]  SW,
    output [6:0]  HEX0, HEX1, HEX2, HEX3, HEX4, HEX5,
    output [9:0]  LEDR
);
    // ---------- 慢时钟：50MHz / 2^25 ≈ 1.5Hz ----------
    reg [24:0] cnt;
    always @(posedge CLOCK_50) cnt <= cnt + 1'b1;
    wire slowclk = cnt[24];

    // ---------- KEY[1]消抖（约21ms稳定才认） ----------
    reg [19:0] dcnt;
    reg key_s, key_clean;
    always @(posedge CLOCK_50) begin
        key_s <= ~KEY[1];                 // 按下=1
        if (key_s == key_clean) dcnt <= 20'h0;
        else begin
            dcnt <= dcnt + 1'b1;
            if (&dcnt) key_clean <= key_s;
        end
    end

    // ---------- CPU时钟选择 ----------
    wire cpuclk = SW[8] ? key_clean : slowclk;

    // ---------- 单周期计算机 ----------
    wire [31:0] inst, pc, aluout, memout;
    sccomp comp (cpuclk, KEY[0], inst, pc, aluout, memout);

    // ---------- 数码管显示 ----------
    wire [15:0] alushow = SW[9] ? aluout[31:16] : aluout[15:0];
    seg7 h0 (alushow[3:0],   HEX0);
    seg7 h1 (alushow[7:4],   HEX1);
    seg7 h2 (alushow[11:8],  HEX2);
    seg7 h3 (alushow[15:12], HEX3);
    seg7 h4 (pc[5:2],        HEX4);   // 指令序号低4位
    seg7 h5 ({2'b00,pc[7:6]},HEX5);   // 指令序号高2位

    // ---------- LED指示 ----------
    assign LEDR[0]   = cpuclk;
    assign LEDR[9:1] = 9'b0;
endmodule
